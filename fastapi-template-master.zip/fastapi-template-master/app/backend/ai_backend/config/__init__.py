# _*_ coding: utf-8 _*_
"""Configuration package."""
from .simple_settings import settings

__all__ = [
    "settings"
]
